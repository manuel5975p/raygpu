#define SINFL_IMPLEMENTATION
#define SDEFL_IMPLEMENTATION
#include <sinfl.h>
#include <sdefl.h>
