#define MSF_GIF_IMPL
#include "msf_gif.h"
